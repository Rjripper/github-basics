<?php
/**
 * Created by PhpStorm.
 * User: nancy
 * Date: 26-2-2018
 * Time: 11:06
 */
/* =====================================================================================================================
                                           require_once
========================================================================================================================
we gebruiken requierde once, omdat we nog steeds de constanten gebruiken
 om de database host, gebruikersnaam, wachtwoord en de database naam.*/
require_once (LIB_PATH.DS."config.php");

/* je zult je vast afvragen waarom je we geen database gebruiken voor ons class, maar de denkwijze is
dat als ik een nieuwe class aan zou maken voor elke database type, dan zou het handig zijn
om voor ons naar een andere database te ruilen, voor als we in de toekomst nog nieuwe databases maken*/
/* hieronder komen alleen maar specifieke functions in met betrekken van mysql
*/
class MySQLDatabase
{


    /*======================================================================================================================
                                            Database connection
    ========================================================================================================================
     de mysqli_connect en voorbijgaand in deze constanten
    in order maakt hij een connectie. En dan kijkt hij naar een paar
    error checking om te maken dat er daar geen error is in de functie
    omdat de variable buiteen de functie is. wordt hij niet opgeslagen.

    door de conntectie vast te houden maken we een private attribuut en dan
    assign we met de attribute $this->> connection, nu hebben we onze connectie gemaakt
    en is het mogelijk om de andere functie in de klas te gaan gebruiken.
    */
    private $connection;

    /* Hieronder in de constructor roep je met this de functie open_connectie aan
    */
    function __construct()
    {
        $this->open_connection();
    }

    /* =================================================================================================================
                                     maakt een nieuwe database
    ====================================================================================================================
    */
    public function open_connection()
    {
        $this->connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
        if (mysqli_connect_errno()) {
            die("Database connection failed:" .
                mysqli_connect_error() .
                "(" . mysqli_connect_errno() . ")"
            );
        }
    }

    /* =================================================================================================================
                                         close Connection
    ====================================================================================================================
    we willen geen locale variable gebruiken voor onze connectie, dus hebben
    we een attribute nodig. We hebben een this nodig en de ->*/
    public function close_connection()
    {
        if (isset($this->connection)) {
            mysqli_close($this->connection);
            unset($this->connection);
        }
    }

    // in deze blok function query en comfirm query heb je nodig
    // perform database query
    public function query($sql)
    {
        $result = mysqli_query($this->connection, $sql);
        $this->confirm_query($result);
        return $result;
    }

    private function confirm_query($result){
        if (!$result) {
            die("Database query failed");
        }
    }

    public function escape_value($string){
        $escaped_string = mysqli_real_escape_string($this->connection,
            $string);
        return $escaped_string;
    }

    // "database neutral" functions

    public function fetch_array($result_set){
        return mysqli_fetch_array($result_set);
    }

    public  function num_rows($result_set){
        return mysqli_num_rows($result_set);
    }

    public function insert_id(){
        // get the last id inserted over the current db
        //connection
        return mysqli_insert_id($this->connection);
    }

    public function affected_rows(){
        return mysqli_affected_rows($this->connection);
    }
}


$database = new MySQLDatabase();
$db =& $database;

?>
