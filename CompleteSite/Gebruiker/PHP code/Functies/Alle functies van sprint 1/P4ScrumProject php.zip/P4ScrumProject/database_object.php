<?php
/**
 * Created by PhpStorm.
 * User: nancy
 * Date: 10-3-2018
 * Time: 12:34
 */
// If it's going to need the database, then it's
// probably smart to requiere it before we start.
require_once (LIB_PATH.DS.'database.php');

class DatabaseObject {

    protected static $table_name="gebruikers";
    protected static $db_fields = array("Gebruikers_ID", "Gebruikers_Voornaam", "Gebruikers_Tussenvoegsel", "Gebruikers_Achternaam", "Gebruikers_Email",
                                  "Gebruikers_Telefoonnummer", "Gebruikers_Gebruikersnaam", "Gebruikers_Wachtwoord", "Gebruikers_Rol"  );

    public static function find_all(){
        //global $database;
        // $result_set = $database->query("SELECT * FROM users");
        // return $result_set;
        return static::find_by_sql("SELECT * FROM ".static::$table_name);
    }

    public static function find_by_id($id=0) {
        global $database;
        $result_array = static::find_by_sql("SELECT * FROM ".static::$table_name." WHERE id={$database->escape_value($id)} LIMIT 1");
        return !empty($result_array) ? array_shift($result_array) : false;
    }


//        global $database;
//        $result_array = static::find_by_sql("SELECT * FROM
//    ".static::$table_name." WHERE id= {$database->escape_value($id)} LIMIT 1");
//        return !empty($result_array) ? array_shift($result_array) : false;



    public static  function find_by_sql($sql=""){
        global $database;
        $result_set = $database->query($sql);
        $object_array = array();
        while ($row = $database->fetch_array($result_set)){
            $object_array[] = static::instantiate($row);
        }
        return $object_array;
    }

    //WEET NIET OF WE DIE MOETEN GEBRUIKEN.
    public static function count_all(){
        global $database;
        $sql = "SELECT COUNT(*) FROM ".static::$table_name;
        $result_set = $database->query($sql);
        $row = $database->fetch_array($result_set);
        return array_shift($row);
    }

    private static function instantiate($record){

        //could check that $record exists and is an array
        $object = new static();
        // simple, long-form approach:
//
//        $object->id         = $record['id'];
//        $object->username   = $record['username'];
//        $object->password   = $record['password'];
//        $object->first_name = $record['first_name'];
//        $object->last_name  = $record['last_name'];

        //more dynamic, short-form approach:
        foreach ($record as $attribute=>$value){
            if ($object->has_attribute($attribute)){
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    protected function has_attribute($attribute){
        //get_object_vars returns an associative array with all
        //attributes
        //(incl. private ones!) as the keys and their current values as
        // the value
        $object_vars = $this->attributes();
        // we don't care about the value, we just want to know if the key
        // exists
        // will return true of false
        return array_key_exists($attribute,$object_vars);
    }

    protected function attributes(){
        // return an array of attribute keys and their values
        $attributes = array();
        foreach (static::$db_fields as $field){
            if(property_exists($this, $field)){
                $attributes[$field] = $this->$field;
            }
        }
        return $attributes;
    }

    protected function sanitized_attributes(){
        global $database;
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: Does not alter te actual value of each attribute
        foreach ($this->attributes() as $key => $value){
            $clean_attributes[$key] = $database->escape_value($value);
        }
        return $clean_attributes;
    }



}
