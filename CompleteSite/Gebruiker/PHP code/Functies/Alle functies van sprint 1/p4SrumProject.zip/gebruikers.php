<?php
/**
 * Created by PhpStorm.
 * User: tim7v
 * Date: 26-4-2018
 * Time: 09:29
 */
require_once ('initialize.php');

class Gebruikers extends DatabaseObject {

    protected static $table_name="gebruikers";
    protected static $db_fields = [];

    public $Gebruikers_Achternaam;
    public $Gebruikers_Email;
    public $Gebruikers_Gebruikersnaam;
    public $Gebruikers_ID;
    public $Gebruikers_Rol;
    public $Gebruikers_Telefoonnummer;
    public $Gebruikers_Tussenvoegsel;
    public $Gebruikers_Voornaam;
    public $Gebruikers_Wachtwoord;


    // zet de db_fields
    public function __construct()
    {
        static::$db_fields = $this->sanitized_attributes();
    }


    public function full_name()
    {
        if(isset($this->Gebruikers_Voornaam) && isset($this->Gebruikers_Tussenvoegsel) && isset($this->Gebruikers_Achternaam))
        {
            return $this->Gebruikers_Voornaam . " " .$this->Gebruikers_Tussenvoegsel . " " . $this->Gebruikers_Achternaam;
        }
        else{
            return "";
        }
    }

    //weet of de gebruiker in de database zit.
    public static function authenticate($username="" , $password="")
    {
        global $database;
        $username = $database->escape_value($username);
        $password = $database->escape_value($password);

        $sql  = "SELECT * FROM gebruikers WHERE Gebruikers_Gebruikersnaam = '{$username}'
                  AND Gebruikers_Wachtwoord = '{$password}' LIMIT 1";
        $result_array = self::find_by_sql($sql);
        return !empty($result_array) ? array_shift($result_array) : false;
    }

}
?>