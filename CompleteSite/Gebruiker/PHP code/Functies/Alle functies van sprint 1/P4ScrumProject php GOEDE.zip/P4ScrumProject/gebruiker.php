<?php
/**
 * Created by PhpStorm.
 * User: nancy
 * Date: 15-5-2018
 * Time: 11:16
 */
require_once (LIB_PATH.DS. 'database.php');
class gebruiker extends DatabaseObject{
    public $id;
    public $voornaam;
    public $tussenvoegsel;
    public $achternaam;
    public $email;
    public $telefoonnummer;
    public $gebruikersnaam;
    public $wachtwoord;
    public $rol;
}